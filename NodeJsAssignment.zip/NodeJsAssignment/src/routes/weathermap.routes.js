module.exports = function(app) {
 
    var weathermapController = require('../controllers/weathermap.controller');
    
    // Get Weathermap data
    app.get('/api/weathermap', weathermapController.weatherMap);
}