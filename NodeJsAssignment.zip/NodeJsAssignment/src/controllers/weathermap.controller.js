var checkNoPrimeOrNot=require('../services/commonService');
var datetime = require('node-datetime');

//API Json data
var openWeatherMap = {
   "coord":{
      "lon":139.01,
      "lat":35.02
   
},
   "weather":[      {
         "id":800,
         "main":"Clear",
         "description":"clear sky",
         "icon":"01n"
      
}
   
],
   "base":"stations",
   "main":{
      "temp":285.514,
      "pressure":1013.75,
      "humidity":100,
      "temp_min":285.514,
      "temp_max":285.514,
      "sea_level":1023.22,
      "grnd_level":1013.75
   
},
   "wind":{
      "speed":5.52,
      "deg":311
   
},
   "clouds":{
      "all":0
   
},
   "dt":1485792967,
   "sys":{
      "message":0.0025,
      "country":"JP",
      "sunrise":1485726240,
      "sunset":1485763863
   
},
   "id":1907296,
   "name":"Tawarano",
   "cod":200
};

exports.weatherMap = function(req, res) {

    var timeValue = openWeatherMap.dt;  //get the dateTime value from json
    var dateTime=new Date(+timeValue);  // convert dt into standared Date Time formate

    //Current DateTime
    var currentDateTimeValue = datetime.create();
    var currentDateTime = currentDateTimeValue.format('y-m-d H:M:S'); 

  try{
    //isPrime function call  userId,functionName,action,dateTime
            if(checkNoPrimeOrNot.isPrime(dateTime.getDate()))
            {
                        checkNoPrimeOrNot.auditLog(
                            {userId:openWeatherMap.weather[0].id,functionName:"weatherMap",action:"Number is prime",dateTime:currentDateTime});
                        res.status(200).json({
                        resultSet:openWeatherMap
                        })
            }
            else
            {
                checkNoPrimeOrNot.auditLog(
                    {userId:openWeatherMap.weather[0].id,functionName:"weatherMap",action:"Number is not prime",dateTime:currentDateTime});
                        res.status(200).json({
                            message:"Date is not prime so no date"
                        })
            }
    }catch(error){
            console.log(error.stack);
    }
};























