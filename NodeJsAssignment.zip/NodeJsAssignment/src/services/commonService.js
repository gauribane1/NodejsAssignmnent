var connection = require('../connection');
exports.isPrime = num => {
    for(let i = 2; i < num; i++)
      if(num % i === 0) return false;
    return num > 1;
  },
  
  exports.auditLog=(requestData)=>{

    var sql = "INSERT INTO testdb.AuditLog (userId,functionName,action,dateTime) VALUES "+"('"+requestData.userId+"','"+requestData.functionName+"','"+requestData.action+"','"+requestData.dateTime+"')";
    connection.query(sql, function (err, result) {
      if (err) throw err;
      console.log("1 record inserted");
    });
 }


